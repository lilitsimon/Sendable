// Sendable API endpoint for voice-preserving writing refinement.
const API_ENDPOINT = "https://sendable-three.vercel.app/api/refine-email"
